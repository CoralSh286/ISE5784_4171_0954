package geometries;

import primitives.*;

import java.util.List;
import java.util.Objects;

/**
 * interface for finding the intersection point between the ray and the object
 */
public abstract class Intersectable {
    /**
     * Finding intersection points between the ray and body
     *
     * @param ray {@link Ray} pointing toward the object
     * @return list of intersection Point between the ray and the object
     */
    public final List<Point> findIntersections(Ray ray) {
        var geoList = findGeoIntersections(ray);
        return geoList == null ? null : geoList.stream().map(gp -> gp.point).toList();
    }

    /**
     * Returns intersection points with the bodies
     *
     * @param ray from the camera
     * @return list of intersection points
     */
    public final List<GeoPoint> findGeoIntersections(Ray ray) {
        return findGeoIntersectionsHelper(ray);
    }

    /**
     * Returns intersection points with the bodies
     *
     * @param ray from the camera
     * @return list of intersection points
     */
    protected abstract List<GeoPoint> findGeoIntersectionsHelper(Ray ray);


    /**
     * this class has been written because we want to know the specific geometry the ray cross it over
     * because we added the emission light for each geometry and if we want to calculate the color at the point
     * we have to mind the geometry's color (this class is PDS)
     */
    public static class GeoPoint {
        /**
         * field for a geometry
         */
        public Geometry geometry;
        /**
         * field for a point
         */
        public Point point;

        /**
         * constructor
         *
         * @param geometry for a geometry
         * @param point    for a point
         */
        public GeoPoint(Geometry geometry, Point point) {
            this.geometry = geometry;
            this.point = point;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            return obj instanceof GeoPoint other &&
                    geometry.equals(other.geometry) && point.equals(other.point);
        }

        @Override
        public String toString() {
            return "GeoPoint{" +
                    "geometry=" + geometry +
                    ", point=" + point +
                    '}';
        }
    }

}
