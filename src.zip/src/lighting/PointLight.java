package lighting;

import primitives.*;

/**
 * PointLight class represents a point light in the scene
 */
public class PointLight extends Light implements LightSource {
    private final Point position;
    private double kc = 1;
    private double kl = 0;
    private double kq = 0;

    /**
     * PointLight constructor
     *
     * @param intensity the intensity of the light
     * @param position  the position of the light
     */
    public PointLight(Color intensity, Point position) {
        super(intensity);
        this.position = position;
    }

    @Override
    public Color getIntensity(Point p) {
        double d = position.distance(p);
        return getIntensity().scale(1 / (kc + kl * d + kq * d * d));
    }

    @Override
    public Vector getL(Point p) {
        return p.equals(position) ? null : p.subtract(position).normalize();
    }

    /**
     * Set the constant attenuation factor
     *
     * @param kc the constant attenuation factor
     * @return kc
     */
    public PointLight setKc(double kc) {
        this.kc = kc;
        return this;
    }

    /**
     * Set the linear attenuation factor
     *
     * @param kl the linear attenuation factor
     * @return kl
     */
    public PointLight setKl(double kl) {
        this.kl = kl;
        return this;
    }

    /**
     * Set the quadratic attenuation factor
     *
     * @param kq the quadratic attenuation factor
     * @return kq
     */
    public PointLight setKq(double kq) {
        this.kq = kq;
        return this;
    }

    //stage 7
    @Override
    public double getDistance(Point point) {
        return point.distance(position);
    }
}


